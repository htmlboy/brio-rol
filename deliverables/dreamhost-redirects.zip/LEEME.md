# Redirecciones antiguas en DreamHost

Las aplicaciones nuevas se alojan en GitHub Pages. DreamHost solo atenderá las direcciones antiguas para redirigirlas.

1. En DreamHost añade sistemabrio.com y online.sistemabrio.com como sitios Fully Hosted, en carpetas vacías dedicadas a las redirecciones. Incluye www.sistemabrio.com como alias del primero. Tu plan debe permitir alojar estos nombres; tener solo el dominio o DNS no basta para HTTPS.
2. En el registrador de sistemabrio.com cambia sus nameservers a ns1.dreamhost.com, ns2.dreamhost.com y ns3.dreamhost.com. No cambies los de briorol.com: permanece en Cloudflare.
3. Cuando las DNS antiguas apunten a DreamHost, activa Let's Encrypt para sistemabrio.com y www, y para online.sistemabrio.com.
4. Sube el archivo .htaccess de este ZIP a la carpeta web de cada sitio antiguo. Activa la vista de archivos ocultos si no aparece. No lo subas a la carpeta de otra web que ya tengas.
5. Comprueba que https://sistemabrio.com/reglas acaba en https://sistema.briorol.com/reglas y que https://online.sistemabrio.com/sala/mi-sala?x=1 acaba en https://online.briorol.com/sala/mi-sala?x=1.
6. Después puedes eliminar los dos proyectos de Netlify y su zona DNS antigua, cuando DreamHost ya responda correctamente.

No selecciones la modalidad básica Redirect para esta receta: se usan Fully Hosted, certificados y .htaccess para atender también las visitas HTTPS. No hace falta WordPress ni base de datos. La ruta de renovación del certificado queda exceptuada.

Mantén registrado sistemabrio.com mientras quieras conservar estas redirecciones. Las direcciones .netlify.app pertenecen a Netlify y no se pueden mantener en DreamHost al borrar los proyectos.
