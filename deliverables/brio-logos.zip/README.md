# Familia Brío — SVG de trabajo

Cinco logos: Brío rol, Brío sistema, Brío online, ruido y dados. Brío sin descriptor se incluye para una firma de procedencia independiente en las webs. Los logos de Ruido y Dados no llevan by Brío.

Cada logo tiene positivo (tinta oscura) y negativo (tinta clara, sufijo -reverse). Los SVG contienen contornos y no necesitan fuentes instaladas. No estirar ni alterar las proporciones entre Brío y su descriptor.

Referencias de pantalla: Brío con descriptor a 120 px de ancho; Ruido y Dados a 96 px. Confirmar lectura en el soporte final. La procedencia se puede mostrar con Brío enlazado a https://briorol.com/ en el pie o la navegación, fuera del logo de la herramienta.

Brío conserva el dibujo original del autor. Los descriptores usan IBM Plex Sans 450, convertida a contornos, bajo SIL OFL. Ruido y Dados son dibujos vectoriales de esta propuesta. Consultar GUIA.md y los avisos de derechos.

El descriptor acordado es online y el dominio previsto online.briorol.com. Dados es una herramienta futura. La entrega de archivos no cambia las webs publicadas.
